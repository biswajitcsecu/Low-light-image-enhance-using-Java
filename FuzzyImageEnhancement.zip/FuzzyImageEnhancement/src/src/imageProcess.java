package src;


import org.opencv.core.*;

public class imageProcess {
	public Mat srcimg;
	
	public imageProcess(Mat img) {
		srcimg=img;
	}
	
	
	//Parametric S-fuzzification
	public Mat parametricSFuzzific(Mat img) {
	Mat imgC = new Mat();
	Size sizeA = srcimg.size();
	for (int i = 0; i < sizeA.height; i++)
		for (int j = 0; j < sizeA.width; j++) {
			double[] data = srcimg.get(i, j);
			if(data[0]<0) {               
			imgC.put(i, j, 0);
			}
			else if (0 <data[0]|| data[0]<=0.5) {
				double x=(data[0]*data[0])/0.5;
				imgC.put(i, j, x);				
			}
			else if (0.5 <data[0]|| data[0]<=1) {
				double x=1-((data[0]-1)*(data[0]-1))/0.5;
				imgC.put(i, j, x);
			}
			else if(data[0]>=1.0) {               
				imgC.put(i, j, 1);
				}
				
		}
	return imgC;
	}	
	



}
