/**
 *
 */

/**
 * @author lunax
 *
 */
import org.opencv.core.Core;
import org.opencv.core.Mat;
import static java.lang.System.loadLibrary;
import static java.lang.System.out;
import org.opencv.imgcodecs.*;
import org.opencv.core.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import org.opencv.core.CvType;
import org.opencv.imgproc.Imgproc;
import java.awt.*;
import javax.swing.*;


class ContrastEnhanceMethod {
	// matrix to bufferedImage
	public  BufferedImage Mat2BufferedImage(Mat m)
	{
		int type = BufferedImage.TYPE_BYTE_GRAY;
		if (m.channels() > 1)
		{
			type = BufferedImage.TYPE_3BYTE_BGR;
		}
		int bufferSize = m.channels()*m.cols()*m.rows();
		byte[] b = new byte[bufferSize];
		m.get(0, 0, b);
		BufferedImage image = new BufferedImage(m.cols(), m.rows(), type);
		final byte[] targetPixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
		System.arraycopy(b, 0, targetPixels, 0, b.length);
		return image;
	}

	//Display an Image
	public void displayImage(Image img)
	{
		ImageIcon icon = new ImageIcon(img);
		JFrame frame = new JFrame();
		frame.setLayout(new FlowLayout());
		frame.setSize(img.getWidth(null)+50, img.getHeight(null)+50);
		JLabel lbl = new JLabel();
		lbl.setIcon(icon);
		frame.add(lbl);
		frame.setVisible(true);
		frame.setTitle("Display");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}


	void rundemo() {
		//Load image
		String filename="/home/lunax/Projects/eclipse/FuzzyContrastEnhance/bin/src.png";
		Mat srcimg = Imgcodecs.imread(filename,Imgcodecs.IMREAD_COLOR);
		out.println("mat ="+srcimg.width() +" x "+srcimg.height() +","+ srcimg.type());

		if(srcimg.empty()){
			System.out.println("Error file not found");
			System.exit(0);
		}
		//Gray image creating the empty destination matrix
		Mat grayimg = new Mat();

		// Converting the image to gray scale and
		Imgproc.cvtColor(srcimg, grayimg, Imgproc.COLOR_RGB2GRAY);

		// Pixel  fuzzification
		Mat imgC = grayimg.clone();

		//convert float to int
		grayimg.convertTo(imgC, CvType.CV_32F);

		//fuzzification
		Size sizeA = grayimg.size();
		for (int i = 0; i < sizeA.height; i++)
			for (int j = 0; j < sizeA.width; j++) {
				double[] data = grayimg.get(i, j);
				data[0] = (255-data[0]) / (255);
				imgC.put(i, j, data);
			}

		//Parametric fuzzy image schemes
		BufferedImage grim = Mat2BufferedImage(grayimg);
		displayImage(grim);

		//Fuzzy manipulation
		Mat imgD = imgC.clone();
		Size sizeD = grayimg.size();
		for (int i = 0; i < sizeD.height; i++)
			for (int j = 0; j < sizeD.width; j++) {
				double[] data = imgD.get(i, j);
				if (data[0]<0.5) {
					data[0] = 2*data[0]*data[0];
					imgD.put(i, j, data);}
				else {
					data[0] = 1-2*(1-data[0])*(1-data[0]);
					imgD.put(i, j, data);
				}
			}

		//defuzzification
		Mat imgF = imgD.clone();
		Size sizeF = grayimg.size();
		for (int i = 0; i < sizeF.height; i++)
			for (int j = 0; j < sizeF.width; j++) {
				double[] data = imgD.get(i, j);
				data[0] = (1.0-data[0])* (255);
				imgF.put(i, j, data);
			}

		//convert float to int
		imgF.convertTo(imgF, CvType.CV_8U);

		//enhanced image
		BufferedImage enhim = Mat2BufferedImage(imgF);
		displayImage(enhim);

	}
}

//main class
public class FuzzyContrastEnhance {
	static {loadLibrary(Core.NATIVE_LIBRARY_NAME);}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {

			ContrastEnhanceMethod obj= new ContrastEnhanceMethod();
			obj.rundemo();

		}
		catch (Exception e)
		{
			System.out.println("Error: " + e.getMessage());
			System.err.println("Error: " + e.getMessage());
		}
	}

}
