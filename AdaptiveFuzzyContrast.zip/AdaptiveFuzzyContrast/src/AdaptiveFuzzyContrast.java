

import org.opencv.core.Core;
import org.opencv.core.Mat;
import static java.lang.System.out;
import org.opencv.imgcodecs.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import org.opencv.core.CvType;
import org.opencv.imgproc.Imgproc;
import java.awt.*; 
import javax.swing.*;  
import java.lang.Math;


//class for 2nd stage

class FuzzyParaImageEnhance {

	public Mat src =new Mat();
	double L = 255.0;

	FuzzyParaImageEnhance(Mat img) {		
		src=img;
	}

	//image fuzzification
	public Mat Parafuzzification(Mat img, int h, int w){
		for (int i = 0; i < h; i++)
			for (int j = 0; j < w; j++) {
				double[] data = img.get(i, j);
				if (data[0]<0.0) {
					data[0] = 0.0;
					img.put(i, j, data);
				}
				else if ( data[0] <= 0.5) {
					data[0] = Math.abs((data[0]*data[0])/0.99);
					img.put(i, j, data);						
				}
				else if (data[0] >= 0.5) {
					data[0] =Math.abs(1-((data[0]-1)*(data[0]-1))/.99);
					img.put(i, j, data);						
				}
			}
		return img;
	}

	//image fuzzy entropy measure
	public double Fuzzyentropy(Mat img, int h, int w){
		double sum = 0.0;
		double fuzent = 0.0;
			for (int i = 0; i < h; i++)
			for (int j = 0; j < w; j++) {
				double[] data = img.get(i, j);				
				fuzent = sum + (data[0]*(1-data[0])) / (h*w);
			}
		return Math.sqrt(L*L*h*w)*fuzent;
	}

	// fuzzy stdev calculation
	public double stdev(Mat img, int h, int w){
		double sum = 0.0;
		double mean = 0.0;
		double num=0.0;
		double numi = 0.0;
		for (int i = 0; i < h; i++)
			for (int j = 0; j < w; j++) {
				double[] data = img.get(i, j);
				sum+=data[0];
			}
		mean = sum/(w*h);

		for (int i = 0; i < h; i++)
			for (int j = 0; j < w; j++) {
				double[] data = img.get(i, j);
				numi = Math.pow((data[0]-mean), 2);
				num+=numi;
			}
		return Math.sqrt(L*L*h*w)*Math.sqrt(num/(w*h));
	}

	//Fuzzy image bias measure  
	public double Fuzzybiasmeasure(Mat img, int h, int w){
		double sum = 0.0;
		double fuzbias = 0.0;
		double x = stdev(img, h,w);
		for (int i = 0; i < h; i++)
			for (int j = 0; j < w; j++) {
				double[] data = img.get(i, j);
				fuzbias = sum + (data[0]-x) / (L*(data[0]-x)*20*h*w);					
			}
		return Math.sqrt(L*L*h*w*h*w)*fuzbias;
	}

	//Fuzzy image sharpness hmeasure
	public double Fuzzysharphmeasure(Mat img, int h, int w){

		double sum = 0.0;
		double sharp = 0.0;
		double x = 0.0;
		for (int i = 0; i < h; i++)
			for (int j = 0; j < w; j++) {
				double[] data = img.get(i, j);
				x = ((1-data[0])/(1+data[0]));
				sharp = sum + (Math.min(x*data[0], (1-data[0]))/ (20*h*w));
			}
		return Math.sqrt(L*w*h*w*h)*sharp;
	}

	//Fuzzy image manipulation
	public Mat ParaFuzzyManipulation(Mat img, int h, int w, double fuzentro){
		double a=0;
		double b=0;
		double x=0;
		for (int i = 0; i < h; i++)
			for (int j = 0; j < w; j++) {
				double[] data = img.get(i, j);
				x = .5*((1-data[0])/(1+data[0]))*fuzentro;
				a=(1-Math.exp(-data[0])/(1-x*Math.exp(-1)));
				b=(1-Math.exp(-data[0])/(1-x*Math.exp(-1)));
				if (data[0]<0.5) {
					data[0] =(1-(Math.sin(a)*(1-2*data[0]))/Math.sin(a));
					img.put(i, j, data);}                
				else {
					data[0] = (1-(Math.sin(b)*(2*data[0]-1))/Math.sin(b));	
					img.put(i, j, data);
				}
			}
		return img;
	}

	//fuzz image discremenets calculation
	public Mat Fuzzymembershipdiscreme(Mat imga, Mat imgb, int h, int w,double fuzzbias, double fuzzsharp){
		for (int i = 0; i < h; i++)
			for (int j = 0; j < w; j++) {
				double[] datax = imga.get(i, j);
				double[] datay = imga.get(i, j);
				datay[0] =fuzzbias*Math.abs(Math.min(datax[0],datay[0])-Math.max(datax[0],datay[0]));
				datax[0] =datax[0]+fuzzsharp*datay[0]+
						fuzzsharp*(Math.max(datax[0], datay[0])-Math.min(datax[0],datay[0]));
				imga.put(i, j, datax);
			}
		return imga;
	}
} 

//class for 1st stage

class FuzzyImageEnhance {	
	double L = 256.0;	
	FuzzyImageEnhance() {}
	// matrix to bufferedImage
	public  BufferedImage Mat2BufferedImage(Mat m){
		int type = BufferedImage.TYPE_BYTE_GRAY;
		if (m.channels() > 1)
		{
			type = BufferedImage.TYPE_3BYTE_BGR;
		}
		int bufferSize = m.channels()*m.cols()*m.rows();
		byte[] b = new byte[bufferSize];
		m.get(0, 0, b); 
		BufferedImage image = new BufferedImage(m.cols(), m.rows(), type);
		final byte[] targetPixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
		System.arraycopy(b, 0, targetPixels, 0, b.length);  
		return image;
	}

	//Display an Image 
	public void displayImage(Image img)	{   
		ImageIcon icon = new ImageIcon(img);
		JFrame frame = new JFrame();
		frame.setLayout(new FlowLayout());        
		frame.setSize(img.getWidth(null)+50, img.getHeight(null)+50);     
		JLabel lbl = new JLabel();
		lbl.setIcon(icon);
		frame.add(lbl);
		frame.setVisible(true);
		frame.setTitle("Display");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	//image fuzzification
	public Mat fuzzification(Mat img, int h, int w){
		for (int i = 0; i < h; i++)
			for (int j = 0; j < w; j++) {
				double[] data = img.get(i, j);
				data[0] = (255-data[0]) / (255);               
				img.put(i, j, data);
			}
		return img;
	}

	//Fuzzy image manipulation
	public Mat FuzzyManipulation(Mat img, int h, int w){

		for (int i = 0; i < h; i++)
			for (int j = 0; j < w; j++) {
				double[] data = img.get(i, j);
				if (data[0]<0.5) {
					data[0] = 2*data[0]*data[0];
					img.put(i, j, data);}                
				else {
					data[0] = 1-2*(1-data[0])*(1-data[0]);	
					img.put(i, j, data);
				}
			}
		return img;
	}	

	// defuzzification
	public Mat defuzzification(Mat imga, Mat imgb, double fueno, double fuzzbias, double fuzzsharp, int h, int w){ 
		double ldfy=Math.sqrt(w*h);
		double ldfx=Math.sqrt(4*ldfy)*(fueno+ fuzzbias+ fuzzsharp)/3;		
		double eta =(fueno+ fuzzbias+ fuzzsharp)*Math.sqrt(w*h);
		for (int i = 0; i <h; i++)
			for (int j = 0; j <w; j++) {
				double[] datax = imga.get(i, j);
				double[] datay = imgb.get(i, j);
				datay[0] = fueno*Math.abs(Math.max(datax[0],1-datay[0])- Math.min((1-datax[0]),datay[0]))/ldfy;
				datax[0] = ((eta*Math.abs((datax[0]-datay[0])*ldfx)
						-fuzzsharp*Math.abs(Math.min(datax[0],1-datay[0])- Math.max(1-datax[0],datay[0]))/ldfy
						-fueno*Math.abs(Math.min(1-datax[0],datay[0]) - Math.max(datax[0],1-datay[0]))/ldfy
						-fuzzsharp*Math.abs(Math.min(1-datax[0],datay[0])- Math.max(datax[0],1-datay[0]))/ldfy
						)/.65)* L;               
				imga.put(i, j, datax);
			}
		return imga;
	}


	//execution
	public void run() {

		//Load image 
		Mat srcimg= Imgcodecs.imread("/home/lunax/Projects/eclipse/AdaptiveFuzzyContrast/bin/src.png",Imgcodecs.IMREAD_COLOR);
		out.println("mat ="+srcimg.width() +" x "+srcimg.height() +","+ srcimg.type());

		if(srcimg.empty()){
			System.out.println("Error file not found"); 				
			System.exit(0);
		}

		//creating gray image 
		Mat grayimg = new Mat(); 
		Mat imgfuzz =new Mat();
		Mat imgfuzzman =new Mat();
		Mat imgfuzzud =new Mat();
		Mat imgpfuzz =new Mat();
		Mat imgpfuzzman =new Mat();
		Mat imgpfuzzud =new Mat();

		// Converting the rgb image to gray scale        
		Imgproc.cvtColor(srcimg, grayimg, Imgproc.COLOR_RGB2GRAY); 

		//display src image
		BufferedImage gimg = Mat2BufferedImage(grayimg);
		displayImage(gimg);

		//convert int  to float
		grayimg.convertTo(grayimg, CvType.CV_32F);

		int w= srcimg.width();  
		int h=srcimg.height();


		//******************Paramatric fuzzy image processing*****************
		FuzzyParaImageEnhance fpi=new FuzzyParaImageEnhance(grayimg);

		// image  fuzzification  
		imgfuzz= fuzzification(grayimg, h, w);
		  
		//image parametric fuzzification and entropy,bias and local ambiguity of sharpness measure
		
		imgpfuzz= fpi.Parafuzzification(imgfuzz, h, w);
	  
		//Parameters measures
		double fuzentro = fpi.Fuzzyentropy(imgfuzz, h, w);
		double fuzzbias = fpi.Fuzzybiasmeasure(imgfuzz, h, w);
		double fuzzsharp = fpi.Fuzzysharphmeasure(imgfuzz, h, w);
		
		System.out.println(fuzentro);
		System.out.println(fuzzbias);
		System.out.println(fuzzsharp);

	
		// membership  manipulation		
		imgfuzzman= FuzzyManipulation(imgfuzz, h, w);
		
		//Parametric membershipgrade manipulation
		imgpfuzzman =fpi.ParaFuzzyManipulation(imgpfuzz, h, w, fuzentro);

		// fuzzy membership grade discriment
		imgpfuzzud =fpi.Fuzzymembershipdiscreme(imgfuzz, imgpfuzzman, h, w, fuzzbias,fuzzsharp);
		
//		for(int i = 0; i < h; i++){ for(int j = 0; j < w; j++){
//		    System.out.print(imgpfuzzman.get(i, j)+" "); } System.out.println(" "); } 
	
		//*************fuzzy membeship defuzzification******************// 
		//defuzzification		
		imgfuzzud = defuzzification(imgfuzzman,imgpfuzzud,fuzentro, fuzzbias, fuzzsharp, h, w);
		  
		//convert float to int datatype
		imgfuzzud.convertTo(imgfuzzud, CvType.CV_8U);

		//Enhanced image
		BufferedImage enhim = Mat2BufferedImage(imgfuzzud);
		displayImage(enhim);

	}  
}

//Main class
public class AdaptiveFuzzyContrast {	

	public static void main(String[] args) {
		// main method stub
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);	
		try{  
			new FuzzyImageEnhance().run();			
		}
		catch (Exception e) 
		{ 
			System.out.println("Error: " + e.getMessage()); 
			System.err.println("Error: " + e.getMessage());			
		} 
	}	
}
